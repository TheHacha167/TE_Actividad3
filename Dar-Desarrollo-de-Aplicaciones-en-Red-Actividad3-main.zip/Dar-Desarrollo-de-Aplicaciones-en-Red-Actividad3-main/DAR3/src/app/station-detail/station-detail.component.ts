import { Component } from '@angular/core';

@Component({
  selector: 'app-station-detail',
  standalone: false,
  
  templateUrl: './station-detail.component.html',
  styleUrl: './station-detail.component.css'
})
export class StationDetailComponent {

}
